
<?php
function get_source() {
    $site = "https://m.facebook.com";
    $curl = curl_init($site);
    
    
    $useragent = 'Mozilla/5.0 (Linux; Android 10; REALME RMX1911 Build/NMF26F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.111 Mobile Safari/537.36 AlohaBrowser/2.20.3';
    
    
    
    curl_setopt($curl, CURLOPT_USERAGENT, $useragent);
    
    
    curl_setopt($curl, CURLOPT_REFERER, 'https://m.facebook.com/');
    
    
    $cookie_file = 'cookie.txt';
    
    
    
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie_file);
    
    
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie_file);
    
    
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    
    
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    
    
    $source = curl_exec($curl);
    
    return $source;
    
    
    curl_close($curl);
}

get_source();


function get_input($source,$name) {
    $dom = new DOMDocument();
    
    $dom->loadHTML($source);
    
    $xp = new DOMXpath($dom);
    $nodes = $xp->query('//input[@name="'.$name.'"]');
    $node = $nodes->item(0);
    
    $get = $node->getAttribute('value'); 
    
    
    return $get;


}

function getErr($source) {
    $dom = new DOMDocument();
    
    $dom->loadHTML($source);
    
    $xp = new DOMXpath($dom);
    $nodes = $xp->query('//div[@class="q"]');
    $node = $nodes->item(0);
    
    $get = $node->textContent;
    
    
    return $get;


}

// function to get webpage title
function getTitle($url) {
    $page = file_get_contents($url);
    $title = preg_match('/<title[^>]*>(.*?)<\/title>/ims', $page, $match) ? $match[1] : null;
    return $title;
}


?>